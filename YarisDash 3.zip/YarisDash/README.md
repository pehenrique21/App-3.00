# Yaris Dash

Painel OBD2 para Toyota Yaris 2021 1.3 com ELM327 Bluetooth (Android).

## Gerar o APK pelo GitHub
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (inclusive a pasta `.github`).
2. Abra a aba **Actions** > **Build APK** > aguarde ficar verde (uns 5 a 8 minutos).
3. Clique na execução e baixe **YarisDash-apk** (um .zip com o APK dentro).
4. Instale no Android (permita "instalar apps desconhecidos").

Se o build falhar, copie o erro do log e me envie.

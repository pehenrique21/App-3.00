package com.yaris.dash

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

val BG = Color(0xFF0B1220)
val PANEL = Color(0xFF121B2E)
val TRACK = Color(0xFF1C2740)
val AMBER = Color(0xFFFFB020)
val RED = Color(0xFFFF4D4F)
val TXT = Color(0xFFE8EEF8)
val MUTED = Color(0xFF7C8AA5)

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) autoConnect()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ObdManager.setup(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) else autoConnect()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = AMBER, background = BG, surface = PANEL)) { App() }
        }
    }

    @SuppressLint("MissingPermission")
    private fun autoConnect() {
        try {
            val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
            ObdManager.autoConnect(ad.bondedDevices ?: emptySet())
        } catch (_: Exception) {}
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🏎" to "Painel", "📊" to "Sensores", "⚠" to "Falhas", "🩺" to "Diagnóstico", "🔌" to "Conexão")
    Scaffold(
        containerColor = BG,
        bottomBar = {
            NavigationBar(containerColor = PANEL) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.first, fontSize = 18.sp) },
                        label = { Text(t.second, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> Dashboard(); 1 -> Sensors(); 2 -> Faults(); 3 -> Diagnostics(); else -> Connect() }
        }
    }
}

// ------------------------------------------------------------ Painel
@Composable
fun Dashboard() {
    val t by ObdManager.telemetry.collectAsState()
    val gear by ObdManager.gear.collectAsState()
    val cvt by ObdManager.cvt.collectAsState()
    val gearText = if (cvt) (if (t.speed < 2) "P/N" else "D") else if (gear == 0) "N" else gear.toString()

    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wide = maxWidth > maxHeight
            val rpmGauge: @Composable (Modifier) -> Unit = { m ->
                Box(m, contentAlignment = Alignment.Center) {
                    ArcGauge(t.rpm.toFloat(), 7000f, 1000f, 6000f, 1000f, Modifier.fillMaxSize())
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(gearText, color = AMBER, fontSize = 76.sp, fontWeight = FontWeight.Black)
                        Text("${t.rpm} rpm", color = TXT, fontSize = 20.sp)
                    }
                }
            }
            val speedGauge: @Composable (Modifier) -> Unit = { m ->
                Box(m, contentAlignment = Alignment.Center) {
                    ArcGauge(t.speed.toFloat(), 200f, 20f, 9999f, 1f, Modifier.fillMaxSize())
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${t.speed}", color = TXT, fontSize = 72.sp, fontWeight = FontWeight.Black)
                        Text("km/h", color = MUTED, fontSize = 18.sp)
                        Text(consumption(t), color = AMBER, fontSize = 15.sp)
                    }
                }
            }
            if (wide) Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rpmGauge(Modifier.weight(1f).fillMaxHeight()); speedGauge(Modifier.weight(1f).fillMaxHeight())
            } else Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rpmGauge(Modifier.weight(1f).fillMaxWidth()); speedGauge(Modifier.weight(1f).fillMaxWidth())
            }
        }
        MusicBar()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Motor", "${t.coolant} °C", t.coolant > 105, Modifier.weight(1f))
            Chip("Bateria", "%.1f V".format(t.voltage), t.voltage in 0.1f..11.8f, Modifier.weight(1f))
            Chip("Carga", "${t.load} %", false, Modifier.weight(1f))
            Chip("Acelerador", "${t.throttle} %", false, Modifier.weight(1f))
        }
    }
}

fun consumption(t: Telemetry): String {
    if (t.maf <= 0f) return "consumo --"
    val lph = t.maf * 0.343f
    return if (t.speed >= 5) "%.1f L/100km".format(lph / t.speed * 100f) else "%.1f L/h".format(lph)
}

@Composable
fun MusicBar() {
    val ctx = LocalContext.current
    var tr by remember { mutableStateOf<Track?>(null) }
    LaunchedEffect(Unit) {
        while (true) { tr = Music.track(ctx); delay(2000) }
    }
    Row(
        Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(14.dp)).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = { Music.prev(ctx) }) { Text("⏮", color = TXT, fontSize = 20.sp) }
        Column(Modifier.weight(1f)) {
            Text(tr?.title ?: "Música", color = TXT, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                tr?.artist ?: "Para ver o nome da faixa, ative o acesso na aba Conexão",
                color = MUTED, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        TextButton(onClick = { Music.toggle(ctx) }) { Text(if (tr?.playing == true) "⏸" else "▶", color = AMBER, fontSize = 22.sp) }
        TextButton(onClick = { Music.next(ctx) }) { Text("⏭", color = TXT, fontSize = 20.sp) }
    }
}

@Composable
fun Chip(label: String, value: String, warn: Boolean, modifier: Modifier) {
    Column(
        modifier.background(PANEL, RoundedCornerShape(14.dp)).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = MUTED, fontSize = 12.sp)
        Text(value, color = if (warn) RED else TXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ArcGauge(value: Float, max: Float, step: Float, redFrom: Float, labelDiv: Float, modifier: Modifier) {
    val anim by animateFloatAsState(value, tween(180), label = "gauge")
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            color = 0xFF9AA7BF.toInt()
        }
    }
    Canvas(modifier) {
        val minD = size.minDimension
        val stroke = minD * 0.05f
        val r = minD / 2f - stroke
        val c = center
        val tl = Offset(c.x - r, c.y - r)
        val sz = Size(2 * r, 2 * r)
        val frac = (anim / max).coerceIn(0f, 1f)
        val hot = anim >= redFrom
        drawArc(TRACK, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        if (frac > 0.005f) drawArc(if (hot) RED else AMBER, 135f, 270f * frac, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        val n = (max / step).toInt()
        for (i in 0..n * 2) {
            val v = i * step / 2f
            val major = i % 2 == 0
            val a = Math.toRadians((135f + 270f * v / max).toDouble())
            val cs = cos(a).toFloat(); val sn = sin(a).toFloat()
            val r1 = r - stroke * 1.2f
            val r2 = r1 - stroke * (if (major) 1.3f else 0.6f)
            drawLine(
                if (v >= redFrom) RED else Color(0xFF55627C),
                Offset(c.x + cs * r1, c.y + sn * r1), Offset(c.x + cs * r2, c.y + sn * r2),
                strokeWidth = if (major) 3.5f else 1.8f
            )
            if (major) {
                val r3 = r2 - stroke * 1.2f
                paint.textSize = minD * 0.045f
                drawContext.canvas.nativeCanvas.drawText(
                    (v / labelDiv).toInt().toString(), c.x + cs * r3, c.y + sn * r3 + paint.textSize / 3f, paint
                )
            }
        }
        val na = Math.toRadians((135f + 270f * frac).toDouble())
        val ncs = cos(na).toFloat(); val nsn = sin(na).toFloat()
        drawLine(
            if (hot) RED else Color.White,
            Offset(c.x + ncs * r * 0.60f, c.y + nsn * r * 0.60f),
            Offset(c.x + ncs * (r - stroke * 0.2f), c.y + nsn * (r - stroke * 0.2f)),
            strokeWidth = 7f, cap = StrokeCap.Round
        )
    }
}

// ------------------------------------------------------------ Sensores
@Composable
fun Sensors() {
    val t by ObdManager.telemetry.collectAsState()
    val list = listOf(
        "Rotação" to "${t.rpm} rpm",
        "Velocidade" to "${t.speed} km/h",
        "Temp. do motor" to "${t.coolant} °C",
        "Carga do motor" to "${t.load} %",
        "Acelerador" to "${t.throttle} %",
        "Temp. ar admissão" to "${t.iat} °C",
        "Pressão MAP" to "${t.map} kPa",
        "Fluxo de ar (MAF)" to "%.1f g/s".format(t.maf),
        "Nível combustível" to (if (t.fuel < 0) "--" else "${t.fuel} %"),
        "Tensão" to "%.2f V".format(t.voltage),
        "Pressão barométrica" to "${t.baro} kPa",
        "Avanço de ignição" to "%.1f °".format(t.timing),
        "Ajuste curto de combustível" to "%.1f %%".format(t.stft),
        "Ajuste longo de combustível" to "%.1f %%".format(t.ltft),
        "Sonda O2 antes do catalisador" to "%.2f V".format(t.o2a),
        "Sonda O2 depois do catalisador" to "%.2f V".format(t.o2b),
        "Temp. do óleo" to (if (t.oil <= -100) "--" else "${t.oil} °C"),
        "Etanol no combustível" to (if (t.ethanol < 0) "--" else "${t.ethanol} %"),
        "Consumo estimado" to consumption(t).removePrefix("consumo ")
    )
    LazyVerticalGrid(
        GridCells.Adaptive(150.dp), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { (k, v) ->
            Column(Modifier.background(PANEL, RoundedCornerShape(14.dp)).padding(14.dp).fillMaxWidth()) {
                Text(k, color = MUTED, fontSize = 13.sp)
                Text(v, color = TXT, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------------------------------ Falhas
val DTC_INFO = mapOf(
    "P0300" to "Falha de ignição aleatória",
    "P0301" to "Falha de ignição cilindro 1", "P0302" to "Falha de ignição cilindro 2",
    "P0303" to "Falha de ignição cilindro 3", "P0304" to "Falha de ignição cilindro 4",
    "P0171" to "Mistura pobre (banco 1)", "P0172" to "Mistura rica (banco 1)",
    "P0420" to "Eficiência do catalisador abaixo do limite",
    "P0130" to "Sensor de oxigênio (circuito)", "P0133" to "Sensor de oxigênio com resposta lenta",
    "P0136" to "Sonda O2 depois do catalisador (circuito)", "P0141" to "Aquecedor da sonda O2",
    "P0335" to "Sensor de rotação do virabrequim (circuito)",
    "P0113" to "Sensor de temperatura do ar (sinal alto)",
    "P0116" to "Sensor de temperatura do motor (faixa)", "P0117" to "Sensor de temperatura do motor (sinal baixo)",
    "P0128" to "Termostato aberto ou temperatura baixa",
    "P0011" to "Comando de válvulas adiantado (VVT)", "P0012" to "Comando de válvulas atrasado (VVT)",
    "P0441" to "Sistema EVAP com fluxo incorreto", "P0442" to "Vazamento pequeno no EVAP", "P0455" to "Vazamento grande no EVAP",
    "P0500" to "Sensor de velocidade do veículo",
    "P0505" to "Controle de marcha lenta",
    "P0562" to "Tensão do sistema baixa"
)

@Composable
fun Faults() {
    val codes by ObdManager.dtcs.collectAsState()
    val msg by ObdManager.faultMsg.collectAsState()
    val conn by ObdManager.connected.collectAsState()
    val demo by ObdManager.demo.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Códigos de falha", color = TXT, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { ObdManager.readDtcs() }, enabled = conn || demo) { Text("Ler códigos") }
            OutlinedButton(onClick = { confirm = true }, enabled = conn || demo) { Text("Apagar códigos") }
        }
        Text(msg, color = MUTED)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(codes) { c ->
                Column(Modifier.background(PANEL, RoundedCornerShape(14.dp)).padding(14.dp).fillMaxWidth()) {
                    Text(c, color = AMBER, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(DTC_INFO[c] ?: "Pesquise este código para o seu Yaris.", color = TXT)
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Apagar códigos?") },
        text = { Text("Isso apaga os códigos salvos e a luz da injeção. Se o defeito continuar, ela volta.") },
        confirmButton = { TextButton(onClick = { confirm = false; ObdManager.clearDtcs() }) { Text("Apagar") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
    )
}

// ------------------------------------------------------------ Diagnóstico
@Composable
fun Diagnostics() {
    val vin by ObdManager.vin.collectAsState()
    val ready by ObdManager.readiness.collectAsState()
    val frz by ObdManager.freeze.collectAsState()
    val msg by ObdManager.diagMsg.collectAsState()
    val conn by ObdManager.connected.collectAsState()
    val demo by ObdManager.demo.collectAsState()
    val on = conn || demo
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Diagnóstico", color = TXT, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { ObdManager.readVin() }, enabled = on, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Chassi", fontSize = 13.sp) }
            Button(onClick = { ObdManager.readReadiness() }, enabled = on, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Prontidão", fontSize = 13.sp) }
            Button(onClick = { ObdManager.readFreeze() }, enabled = on, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("Congelados", fontSize = 13.sp) }
        }
        Text(msg, color = MUTED, fontSize = 13.sp)
        DiagCard("Chassi (VIN)", listOf(vin))
        DiagCard("Testes de prontidão", ready)
        DiagCard("Dados congelados (quando houve falha)", frz)
    }
}

@Composable
fun DiagCard(title: String, lines: List<String>) {
    Column(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(14.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = AMBER, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        if (lines.isEmpty()) Text("--", color = MUTED) else lines.forEach { Text(it, color = TXT) }
    }
}

// ------------------------------------------------------------ Conexão
@SuppressLint("MissingPermission")
@Composable
fun Connect() {
    val ctx = LocalContext.current
    val status by ObdManager.status.collectAsState()
    val demo by ObdManager.demo.collectAsState()
    val cvt by ObdManager.cvt.collectAsState()
    var devices by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    var granted by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 ||
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    fun refresh() {
        if (!granted) return
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        devices = ad?.bondedDevices?.toList() ?: emptyList()
    }
    LaunchedEffect(granted) { refresh() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Conexão", color = TXT, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(status, color = AMBER)
        Text("Pareie o ELM327 nas configurações de Bluetooth do Android (senha 1234 ou 0000) e escolha abaixo. O app lembra o último scanner e reconecta sozinho.", color = MUTED, fontSize = 13.sp)
        if (!granted) Button(onClick = { if (Build.VERSION.SDK_INT >= 31) launcher.launch(Manifest.permission.BLUETOOTH_CONNECT) }) { Text("Permitir Bluetooth") }
        devices.forEach { d ->
            OutlinedButton(onClick = { ObdManager.connect(d) }, modifier = Modifier.fillMaxWidth()) { Text(d.name ?: d.address) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { refresh() }) { Text("Atualizar lista") }
            OutlinedButton(onClick = { ObdManager.disconnect() }) { Text("Desconectar") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(demo, { ObdManager.setDemo(it) }); Spacer(Modifier.width(8.dp)); Text("Modo demonstração", color = TXT)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(cvt, { ObdManager.setCvt(it) }); Spacer(Modifier.width(8.dp)); Text("Câmbio CVT (mostra D em vez da marcha)", color = TXT)
        }
        HorizontalDivider(color = TRACK)
        Text("Música", color = TXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Os controles ficam na aba Painel. Para mostrar o nome da faixa, ative o acesso do Yaris Dash às notificações.", color = MUTED, fontSize = 13.sp)
        OutlinedButton(onClick = {
            try {
                ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }) { Text("Ativar nome da faixa") }
        OutlinedButton(onClick = {
            try {
                val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            } catch (_: Exception) {}
        }) { Text("Abrir player de música") }
    }
}

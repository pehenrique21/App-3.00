package com.yaris.dash

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.KeyEvent

/** Serviço vazio: só existe para o Android liberar a leitura da música que está tocando. */
class MediaListener : NotificationListenerService()

data class Track(val title: String, val artist: String, val playing: Boolean)

object Music {
    fun hasAccess(ctx: Context): Boolean =
        Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?.contains(ctx.packageName) == true

    private fun controller(ctx: Context): MediaController? = try {
        val m = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        m.getActiveSessions(ComponentName(ctx, MediaListener::class.java)).firstOrNull()
    } catch (e: Exception) {
        null
    }

    fun track(ctx: Context): Track? {
        val c = controller(ctx) ?: return null
        val md = c.metadata
        return Track(
            md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sem título",
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            c.playbackState?.state == PlaybackState.STATE_PLAYING
        )
    }

    fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun prev(ctx: Context) {
        val c = controller(ctx)
        if (c == null) mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS) else c.transportControls.skipToPrevious()
    }

    fun next(ctx: Context) {
        val c = controller(ctx)
        if (c == null) mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT) else c.transportControls.skipToNext()
    }

    fun toggle(ctx: Context) {
        val c = controller(ctx)
        if (c == null) mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        else if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }
}

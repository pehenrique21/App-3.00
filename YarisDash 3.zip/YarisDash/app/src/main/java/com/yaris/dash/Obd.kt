package com.yaris.dash

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.sin

data class Telemetry(
    val rpm: Int = 0,
    val speed: Int = 0,
    val coolant: Int = 0,
    val load: Int = 0,
    val throttle: Int = 0,
    val iat: Int = 0,
    val voltage: Float = 0f,
    val map: Int = 0,
    val maf: Float = 0f,
    val fuel: Int = -1,
    val baro: Int = 0,
    val timing: Float = 0f,
    val stft: Float = 0f,
    val ltft: Float = 0f,
    val o2a: Float = 0f,
    val o2b: Float = 0f,
    val oil: Int = -100,
    val ethanol: Int = -1
)

/** Relação aproximada rpm por km/h em cada marcha (Yaris 1.3 manual 5M). Ajuste se precisar. */
object Gears {
    val K = doubleArrayOf(127.7, 68.9, 47.2, 35.1, 29.0)

    fun detect(rpm: Int, speed: Int): Int {
        if (speed < 4 || rpm < 300) return 0
        val ratio = rpm.toDouble() / speed
        var best = 0
        var bd = Double.MAX_VALUE
        for (i in K.indices) {
            val d = abs(ln(ratio / K[i]))
            if (d < bd) { bd = d; best = i + 1 }
        }
        return if (bd > 0.18) 0 else best
    }
}

private fun IntArray.u8(i: Int) = if (i < size) this[i] else 0

private fun dtcString(b0: Int, b1: Int): String {
    if (b0 == 0 && b1 == 0) return "nenhum"
    val type = "PCBU"[(b0 shr 6) and 3]
    return "$type${(b0 shr 4) and 3}${(b0 and 15).toString(16).uppercase()}${"%02X".format(b1)}"
}

object ObdManager {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var job: Job? = null
    private var demoJob: Job? = null
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var wantConnected = false
    private var prefs: SharedPreferences? = null

    val telemetry = MutableStateFlow(Telemetry())
    val status = MutableStateFlow("Desconectado")
    val connected = MutableStateFlow(false)
    val demo = MutableStateFlow(false)
    val cvt = MutableStateFlow(false)
    val gear = MutableStateFlow(0)
    val dtcs = MutableStateFlow<List<String>>(emptyList())
    val faultMsg = MutableStateFlow("Toque em “Ler códigos”.")
    val vin = MutableStateFlow("--")
    val readiness = MutableStateFlow<List<String>>(emptyList())
    val freeze = MutableStateFlow<List<String>>(emptyList())
    val diagMsg = MutableStateFlow("Toque em um dos botões.")

    fun setup(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("yarisdash", Context.MODE_PRIVATE)
        prefs = p
        cvt.value = p.getBoolean("cvt", false)
    }

    fun setCvt(v: Boolean) {
        cvt.value = v
        prefs?.edit()?.putBoolean("cvt", v)?.apply()
    }

    /** Reconecta sozinho ao último scanner usado. */
    fun autoConnect(bonded: Set<BluetoothDevice>) {
        if (job != null || demo.value) return
        val addr = prefs?.getString("last", null) ?: return
        bonded.firstOrNull { it.address == addr }?.let { connect(it) }
    }

    private var gearCand = 0
    private var gearCount = 0
    private fun updateGear(rpm: Int, speed: Int) {
        val g = Gears.detect(rpm, speed)
        if (g == gearCand) gearCount++ else { gearCand = g; gearCount = 1 }
        if (gearCount >= 3) gear.value = g
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun connect(dev: BluetoothDevice) {
        setDemo(false)
        disconnect()
        prefs?.edit()?.putString("last", dev.address)?.apply()
        wantConnected = true
        job = scope.launch {
            while (wantConnected && isActive) {
                var s: BluetoothSocket? = null
                try {
                    status.value = "Conectando..."
                    BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                    val ns = dev.createRfcommSocketToServiceRecord(SPP)
                    s = ns
                    socket = ns
                    ns.connect()
                    input = ns.inputStream
                    output = ns.outputStream
                    for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) sendRaw(c)
                    connected.value = true
                    status.value = "Conectado: ${dev.name}"
                    poll()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status.value = "Sem conexão (${e.message ?: "erro"}). Tentando de novo..."
                } finally {
                    try { s?.close() } catch (_: Exception) {}
                    if (socket === s) { socket = null; input = null; output = null }
                    connected.value = false
                }
                if (wantConnected) delay(5000)
            }
        }
    }

    fun disconnect() {
        wantConnected = false
        job?.cancel(); job = null
        try { socket?.close() } catch (_: Exception) {}
        connected.value = false
        if (!demo.value) status.value = "Desconectado"
    }

    private suspend fun sendRaw(cmd: String): String {
        val i = input ?: throw IOException("sem conexão")
        val o = output ?: throw IOException("sem conexão")
        while (i.available() > 0) i.read()
        o.write((cmd + "\r").toByteArray()); o.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + 6000
        while (System.currentTimeMillis() < end) {
            if (i.available() > 0) {
                val c = i.read()
                if (c < 0) throw IOException("conexão encerrada")
                if (c == '>'.code) break
                sb.append(c.toChar())
            } else delay(4)
        }
        return sb.toString()
    }

    private fun lines(resp: String): List<String> =
        resp.split('\r', '\n').map { it.replace(" ", "").uppercase() }

    private suspend fun pid(p: String): IntArray? {
        for (l in lines(sendRaw("01$p"))) {
            if (l.startsWith("41$p")) {
                val b = l.substring(4).chunked(2).mapNotNull { it.toIntOrNull(16) }
                if (b.isNotEmpty()) return b.toIntArray()
            }
        }
        return null
    }

    private suspend fun poll() {
        var t = Telemetry()
        val rot = listOf("11", "04", "05", "0F", "42", "0B", "10", "2F", "33", "0E", "06", "07", "14", "15", "5C", "52")
        val fails = HashMap<String, Int>()
        var i = 0
        while (currentCoroutineContext().isActive) {
            mutex.withLock {
                pid("0C")?.let { t = t.copy(rpm = (it.u8(0) * 256 + it.u8(1)) / 4) }
                pid("0D")?.let { t = t.copy(speed = it.u8(0)) }
                val p = rot[i % rot.size]; i++
                if ((fails[p] ?: 0) < 3) {
                    val a = pid(p)
                    if (a == null) fails[p] = (fails[p] ?: 0) + 1
                    else {
                        fails[p] = 0
                        t = when (p) {
                            "11" -> t.copy(throttle = a.u8(0) * 100 / 255)
                            "04" -> t.copy(load = a.u8(0) * 100 / 255)
                            "05" -> t.copy(coolant = a.u8(0) - 40)
                            "0F" -> t.copy(iat = a.u8(0) - 40)
                            "42" -> t.copy(voltage = (a.u8(0) * 256 + a.u8(1)) / 1000f)
                            "0B" -> t.copy(map = a.u8(0))
                            "10" -> t.copy(maf = (a.u8(0) * 256 + a.u8(1)) / 100f)
                            "2F" -> t.copy(fuel = a.u8(0) * 100 / 255)
                            "33" -> t.copy(baro = a.u8(0))
                            "0E" -> t.copy(timing = a.u8(0) / 2f - 64f)
                            "06" -> t.copy(stft = (a.u8(0) - 128) * 100f / 128f)
                            "07" -> t.copy(ltft = (a.u8(0) - 128) * 100f / 128f)
                            "14" -> t.copy(o2a = a.u8(0) / 200f)
                            "15" -> t.copy(o2b = a.u8(0) / 200f)
                            "5C" -> t.copy(oil = a.u8(0) - 40)
                            "52" -> t.copy(ethanol = a.u8(0) * 100 / 255)
                            else -> t
                        }
                    }
                }
            }
            telemetry.value = t
            updateGear(t.rpm, t.speed)
            delay(10)
        }
    }

    // ---------- Códigos de falha ----------
    fun readDtcs() {
        scope.launch {
            if (demo.value) {
                dtcs.value = listOf("P0420"); faultMsg.value = "1 código encontrado (demonstração)."; return@launch
            }
            try {
                val all = mutex.withLock {
                    parseDtc(sendRaw("03"), "43") + parseDtc(sendRaw("07"), "47")
                }.distinct()
                dtcs.value = all
                faultMsg.value = if (all.isEmpty()) "Nenhum código de falha armazenado." else "${all.size} código(s) encontrado(s)."
            } catch (e: Exception) {
                faultMsg.value = "Erro: ${e.message}"
            }
        }
    }

    fun clearDtcs() {
        scope.launch {
            if (demo.value) { dtcs.value = emptyList(); faultMsg.value = "Códigos apagados (demonstração)."; return@launch }
            try {
                mutex.withLock { sendRaw("04") }
                dtcs.value = emptyList()
                faultMsg.value = "Códigos apagados. Com a ignição ligada, a luz deve apagar."
            } catch (e: Exception) {
                faultMsg.value = "Erro: ${e.message}"
            }
        }
    }

    private fun hexLines(resp: String): String {
        val sb = StringBuilder()
        for (raw in resp.split('\r', '\n')) {
            val l = raw.replace(" ", "").uppercase().replace(Regex("^[0-9]:"), "")
            if (l.isEmpty() || l.length == 3) continue
            if (!l.all { it in '0'..'9' || it in 'A'..'F' }) continue
            sb.append(l)
        }
        return sb.toString()
    }

    private fun parseDtc(resp: String, head: String): List<String> {
        var h = hexLines(resp)
        if (!h.startsWith(head)) return emptyList()
        h = h.substring(2)
        if (h.length % 4 == 2) h = h.substring(2)
        val out = mutableListOf<String>()
        for (k in 0 until h.length / 4) {
            val c = h.substring(k * 4, k * 4 + 4)
            if (c == "0000") continue
            out.add(dtcString(c.substring(0, 2).toInt(16), c.substring(2, 4).toInt(16)))
        }
        return out
    }

    // ---------- Diagnóstico: VIN, prontidão, dados congelados ----------
    fun readVin() {
        scope.launch {
            if (demo.value) { vin.value = "9BRBLWHE0M0000000"; return@launch }
            try {
                val h = hexLines(mutex.withLock { sendRaw("0902") })
                val idx = h.indexOf("4902")
                if (idx < 0 || h.length <= idx + 6) { vin.value = "indisponível"; return@launch }
                val v = h.substring(idx + 6).chunked(2).mapNotNull { it.toIntOrNull(16) }
                    .map { it.toChar() }.filter { it.isLetterOrDigit() }.joinToString("")
                vin.value = if (v.isEmpty()) "indisponível" else v.take(17)
            } catch (e: Exception) {
                diagMsg.value = "Erro: ${e.message}"
            }
        }
    }

    fun readReadiness() {
        scope.launch {
            if (demo.value) {
                readiness.value = listOf("Luz da injeção: apagada", "Códigos armazenados: 0", "Catalisador: pronto", "Sensor de oxigênio: pronto", "EVAP: incompleto")
                return@launch
            }
            try {
                val a = mutex.withLock { pid("01") }
                if (a == null || a.size < 4) { diagMsg.value = "O carro não respondeu."; return@launch }
                val out = mutableListOf<String>()
                val mil = (a.u8(0) and 0x80) != 0
                out.add("Luz da injeção: ${if (mil) "ACESA" else "apagada"}")
                out.add("Códigos armazenados: ${a.u8(0) and 0x7F}")
                val b = a.u8(1); val c = a.u8(2); val d = a.u8(3)
                fun mon(name: String, sup: Boolean, inc: Boolean) {
                    if (sup) out.add("$name: ${if (inc) "incompleto" else "pronto"}")
                }
                mon("Falha de ignição", (b and 1) != 0, (b and 0x10) != 0)
                mon("Sistema de combustível", (b and 2) != 0, (b and 0x20) != 0)
                mon("Componentes", (b and 4) != 0, (b and 0x40) != 0)
                val names = listOf("Catalisador", "Catalisador aquecido", "Evaporativo (EVAP)", "Ar secundário",
                    "Ar-condicionado", "Sensor de oxigênio", "Aquecedor do sensor O2", "EGR")
                for (bit in 0..7) mon(names[bit], ((c shr bit) and 1) != 0, ((d shr bit) and 1) != 0)
                readiness.value = out
            } catch (e: Exception) {
                diagMsg.value = "Erro: ${e.message}"
            }
        }
    }

    private suspend fun ff(p: String): IntArray? {
        for (l in lines(sendRaw("02${p}00"))) {
            if (l.startsWith("42${p}00")) {
                val b = l.substring(6).chunked(2).mapNotNull { it.toIntOrNull(16) }
                if (b.isNotEmpty()) return b.toIntArray()
            }
        }
        return null
    }

    fun readFreeze() {
        scope.launch {
            if (demo.value) {
                freeze.value = listOf("Código que gerou o registro: P0420", "Rotação: 2100 rpm", "Velocidade: 62 km/h", "Temp. do motor: 90 °C", "Carga do motor: 41 %")
                return@launch
            }
            try {
                val out = mutableListOf<String>()
                mutex.withLock {
                    ff("02")?.let { out.add("Código que gerou o registro: " + dtcString(it.u8(0), it.u8(1))) }
                    ff("0C")?.let { out.add("Rotação: ${(it.u8(0) * 256 + it.u8(1)) / 4} rpm") }
                    ff("0D")?.let { out.add("Velocidade: ${it.u8(0)} km/h") }
                    ff("05")?.let { out.add("Temp. do motor: ${it.u8(0) - 40} °C") }
                    ff("04")?.let { out.add("Carga do motor: ${it.u8(0) * 100 / 255} %") }
                }
                freeze.value = if (out.isEmpty()) listOf("Nenhum dado congelado guardado.") else out
            } catch (e: Exception) {
                diagMsg.value = "Erro: ${e.message}"
            }
        }
    }

    // ---------- Demonstração ----------
    fun setDemo(on: Boolean) {
        demoJob?.cancel(); demoJob = null
        demo.value = on
        if (!on) { if (!connected.value) status.value = "Desconectado"; return }
        disconnect()
        status.value = "Modo demonstração"
        demoJob = scope.launch {
            var tt = 0.0
            while (isActive) {
                val sp = (50 + 48 * sin(tt / 8.0)).toInt().coerceAtLeast(0)
                val g = when { sp < 20 -> 1; sp < 35 -> 2; sp < 50 -> 3; sp < 70 -> 4; else -> 5 }
                val rpm = maxOf(850, (sp * Gears.K[g - 1]).toInt()) + (sin(tt * 3) * 40).toInt()
                telemetry.value = Telemetry(
                    rpm = rpm, speed = sp, coolant = 90, load = rpm / 70, throttle = (sp * 0.6).toInt(),
                    iat = 32, voltage = 14.1f, map = 40 + sp / 2, maf = 3f + sp / 8f, fuel = 62, baro = 93,
                    timing = 12f, stft = (sin(tt) * 3).toFloat(), ltft = 1.5f, o2a = 0.45f + (sin(tt * 4) * 0.3).toFloat(),
                    o2b = 0.65f, oil = 95, ethanol = 27
                )
                updateGear(rpm, sp)
                tt += 0.1
                delay(100)
            }
        }
    }
}

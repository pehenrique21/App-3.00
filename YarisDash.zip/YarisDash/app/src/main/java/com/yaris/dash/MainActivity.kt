package com.yaris.dash

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.math.*

val BG = Color(0xFF05080F)
val CYAN = Color(0xFF00E5FF)
val RED = Color(0xFFFF3D3D)
// RPM por km/h em cada marcha (Yaris 1.3 manual 5M, pneu 185/60R15). Ajuste se necessario.
val RATIOS = floatArrayOf(127.5f, 68.8f, 47.1f, 35.0f, 28.9f)

class Elm(private val dev: BluetoothDevice) {
    private var s: BluetoothSocket? = null
    private lateinit var i: InputStream
    private lateinit var o: OutputStream

    @SuppressLint("MissingPermission")
    fun open() {
        val sk = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        sk.connect(); s = sk; i = sk.inputStream; o = sk.outputStream
        for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) cmd(c)
    }

    @Synchronized
    fun cmd(c: String): String {
        o.write((c + "\r").toByteArray()); o.flush()
        val sb = StringBuilder()
        while (true) { val b = i.read(); if (b < 0 || b == '>'.code) break; sb.append(b.toChar()) }
        return sb.toString().replace("\r", "").replace("\n", "").replace(" ", "").replace("SEARCHING...", "")
    }

    fun pid(p: String): IntArray? {
        val r = cmd("01$p"); val k = r.indexOf("41$p")
        if (k < 0) return null
        return r.substring(k + 4).chunked(2).mapNotNull { it.toIntOrNull(16) }.toIntArray()
    }

    fun close() { runCatching { s?.close() } }
}

fun conv(p: String, v: IntArray): Float? {
    val a = v.getOrNull(0) ?: return null
    val b = v.getOrNull(1) ?: 0
    return when (p) {
        "0C" -> (a * 256 + b) / 4f
        "0D", "0B" -> a.toFloat()
        "05", "0F", "5C" -> a - 40f
        "04", "11", "2F" -> a * 100 / 255f
        "10" -> (a * 256 + b) / 100f
        "42" -> (a * 256 + b) / 1000f
        "0E" -> a / 2f - 64
        "06", "07" -> (a - 128) * 100 / 128f
        else -> null
    }
}

val KEYS = mapOf("0C" to "rpm", "0D" to "spd", "05" to "cool", "04" to "load", "11" to "thr", "0F" to "iat",
    "10" to "maf", "42" to "volt", "5C" to "oil", "2F" to "fuel", "0B" to "map", "0E" to "adv", "06" to "stft", "07" to "ltft")

fun gearOf(rpm: Float, spd: Float): String {
    if (spd < 4f) return "N"
    val r = rpm / spd
    var best = 0
    for (g in RATIOS.indices) if (abs(r - RATIOS[g]) < abs(r - RATIOS[best])) best = g
    return if (abs(r - RATIOS[best]) / RATIOS[best] > 0.18f) "N" else "${best + 1}"
}

class MainActivity : ComponentActivity() {
    val tel = mutableStateMapOf<String, Float>()
    var status by mutableStateOf("Desconectado")
    var dtcs by mutableStateOf<List<String>?>(null)
    var devices by mutableStateOf(listOf<BluetoothDevice>())
    var elm: Elm? = null
    var job: Job? = null

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { loadDevices() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 31) perm.launch(Manifest.permission.BLUETOOTH_CONNECT) else loadDevices()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Dash() } }
    }

    @SuppressLint("MissingPermission")
    fun loadDevices() {
        devices = runCatching { getSystemService(BluetoothManager::class.java).adapter.bondedDevices.toList() }.getOrDefault(emptyList())
    }

    @SuppressLint("MissingPermission")
    fun nm(d: BluetoothDevice) = d.name ?: d.address

    fun connect(d: BluetoothDevice) {
        job?.cancel()
        job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                status = "Conectando..."
                val e = Elm(d); e.open(); elm = e; status = "Conectado: " + nm(d)
                val slow = listOf("05", "04", "11", "0F", "10", "42", "5C", "2F", "0B", "0E", "06", "07")
                var n = 0
                while (isActive) {
                    for (p in listOf("0C", "0D")) e.pid(p)?.let { v -> conv(p, v)?.let { tel[KEYS[p]!!] = it } }
                    val p = slow[n++ % slow.size]
                    e.pid(p)?.let { v -> conv(p, v)?.let { tel[KEYS[p]!!] = it } }
                }
            } catch (x: Exception) {
                if (x !is CancellationException) status = "Erro: ${x.message}"
            } finally { elm?.close(); elm = null }
        }
    }

    fun demo() {
        job?.cancel()
        job = lifecycleScope.launch(Dispatchers.Default) {
            status = "Modo demonstracao"; var t = 0f
            while (isActive) {
                t += 0.04f
                val s = ((sin(t) + 1) / 2) * 130f
                val g = when { s < 15 -> 0; s < 30 -> 1; s < 50 -> 2; s < 75 -> 3; else -> 4 }
                tel["spd"] = s; tel["rpm"] = min(6500f, max(900f, s * RATIOS[g]))
                tel["cool"] = 90f; tel["oil"] = 95f; tel["iat"] = 32f; tel["load"] = 20 + s / 3; tel["thr"] = 10 + s / 4
                tel["volt"] = 14.1f; tel["fuel"] = 62f; tel["map"] = 45 + s / 3; tel["adv"] = 12f
                tel["stft"] = 1.5f; tel["ltft"] = -0.8f; tel["maf"] = 3 + s / 6
                delay(80)
            }
        }
    }

    fun readDtc() {
        val e = elm
        if (e == null) { dtcs = listOf("Conecte o scanner primeiro"); return }
        lifecycleScope.launch(Dispatchers.IO) {
            val r = runCatching { e.cmd("03") }.getOrDefault("")
            val k = r.indexOf("43")
            dtcs = if (k < 0) emptyList() else r.substring(k + 4).chunked(4).filter { it.length == 4 && it != "0000" }.mapNotNull {
                val v = it.toIntOrNull(16) ?: return@mapNotNull null
                "PCBU"[v shr 14].toString() + ((v shr 12) and 3) + "%03X".format(v and 0xFFF)
            }
        }
    }

    fun clearDtc() {
        val e = elm ?: return
        lifecycleScope.launch(Dispatchers.IO) { runCatching { e.cmd("04") }; dtcs = emptyList() }
    }

    fun key(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun openPlayer() {
        runCatching { startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)) }
    }

    @Composable
    fun Dash() {
        var menu by remember { mutableStateOf(false) }
        val rpm = tel["rpm"] ?: 0f
        val spd = tel["spd"] ?: 0f
        val maf = tel["maf"] ?: 0f
        val tiles = listOf("Água" to "cool", "Óleo" to "oil", "Admissão" to "iat", "Carga" to "load", "Acelerador" to "thr",
            "Bateria" to "volt", "Combustível" to "fuel", "MAP" to "map", "Avanço" to "adv", "STFT" to "stft", "LTFT" to "ltft", "MAF" to "maf")
        Column(Modifier.fillMaxSize().background(BG).padding(10.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                Text(status, color = Color.Gray, modifier = Modifier.padding(end = 8.dp))
                Box {
                    Button({ menu = true }) { Text("Scanner") }
                    DropdownMenu(menu, { menu = false }) {
                        devices.forEach { d -> DropdownMenuItem({ Text(nm(d)) }, { menu = false; connect(d) }) }
                    }
                }
                Spacer(Modifier.width(6.dp)); Button({ demo() }) { Text("Demo") }
                Spacer(Modifier.width(6.dp)); Button({ readDtc() }) { Text("Falhas") }
                Spacer(Modifier.width(6.dp)); Button({ key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }) { Text("⏮") }
                Spacer(Modifier.width(6.dp)); Button({ key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }) { Text("⏯") }
                Spacer(Modifier.width(6.dp)); Button({ key(KeyEvent.KEYCODE_MEDIA_NEXT) }) { Text("⏭") }
                Spacer(Modifier.width(6.dp)); Button({ openPlayer() }) { Text("Música") }
            }
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Box(Modifier.weight(1f).fillMaxHeight(), Alignment.Center) { Gauge(rpm, 7000f, 5500f, "%.0f".format(rpm), "RPM", Modifier.aspectRatio(1f)) }
                Column(Modifier.weight(0.6f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text(gearOf(rpm, spd), color = CYAN, fontSize = 110.sp, fontWeight = FontWeight.Bold)
                    Text("MARCHA", color = Color.Gray, fontSize = 14.sp)
                }
                Box(Modifier.weight(1f).fillMaxHeight(), Alignment.Center) { Gauge(spd, 200f, 120f, "%.0f".format(spd), "km/h", Modifier.aspectRatio(1f)) }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp)) {
                if (maf > 0f && spd > 5f) Tile("Consumo", "%.1f km/L".format(spd / (maf * 0.3287f)))
                tiles.forEach { (l, k) -> Tile(l, tel[k]?.let { "%.1f".format(it) } ?: "--") }
            }
        }
        dtcs?.let { list ->
            AlertDialog(onDismissRequest = { dtcs = null },
                title = { Text("Códigos de falha") },
                text = { Text(if (list.isEmpty()) "Nenhuma falha armazenada" else list.joinToString("\n")) },
                confirmButton = { TextButton({ clearDtc() }) { Text("Apagar códigos") } },
                dismissButton = { TextButton({ dtcs = null }) { Text("Fechar") } })
        }
    }

    @Composable
    fun Tile(label: String, value: String) {
        Column(Modifier.padding(end = 8.dp).background(Color(0xFF101826), RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Color.Gray, fontSize = 11.sp)
        }
    }

    @Composable
    fun Gauge(v: Float, max: Float, red: Float, big: String, unit: String, mod: Modifier) {
        val a by animateFloatAsState(v, tween(250), label = "g")
        Box(mod, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.minDimension; val st = w * 0.07f
                val tl = Offset(st, st); val sz = Size(w - 2 * st, w - 2 * st)
                drawArc(Color(0xFF1A2333), 135f, 270f, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
                val f = (a / max).coerceIn(0f, 1f)
                drawArc(if (a >= red) RED else CYAN, 135f, 270f * f, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
                val c = center; val r = w / 2; val o = r - st * 2f
                for (k in 0..20) {
                    val ang = Math.toRadians(135.0 + 270.0 * k / 20)
                    val len = if (k % 5 == 0) r * 0.12f else r * 0.06f
                    drawLine(Color(0x88FFFFFF),
                        Offset(c.x + (o * cos(ang)).toFloat(), c.y + (o * sin(ang)).toFloat()),
                        Offset(c.x + ((o - len) * cos(ang)).toFloat(), c.y + ((o - len) * sin(ang)).toFloat()), 2f)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(big, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(unit, color = Color.Gray, fontSize = 14.sp)
            }
        }
    }
}

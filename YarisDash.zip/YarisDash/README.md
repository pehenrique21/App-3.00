# Yaris Dash
1. Crie um repositório no GitHub e envie todos estes arquivos (branch main).
2. Aba Actions > Build APK > aguarde ~5 min.
3. Baixe o artefato YarisDash-APK, extraia e instale o .apk no Android.
4. Pareie o ELM327 nas configurações Bluetooth do celular (senha 1234 ou 0000) antes de abrir o app.
